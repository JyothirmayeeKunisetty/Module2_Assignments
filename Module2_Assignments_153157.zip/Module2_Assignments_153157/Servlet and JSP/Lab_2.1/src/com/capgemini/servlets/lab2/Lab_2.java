package com.capgemini.servlets.lab2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Lab_2")
public class Lab_2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
         String un=request.getParameter("username");
         String ps=request.getParameter("password");

		PrintWriter out = response.getWriter();

		
		
		
		if(un.equals("sowmya") && ps.equals("stunt"))
      {RequestDispatcher rd= request.getRequestDispatcher("Success.html");
	   rd.forward(request, response);}
		else
		{
			RequestDispatcher rd= request.getRequestDispatcher("Failure.html");
			   rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}


